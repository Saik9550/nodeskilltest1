const express = require('express');
const router = express.Router();
const { renderForm } = require('../controllers/addStudentController');

router.get('/add-student', renderForm);

module.exports = router;
