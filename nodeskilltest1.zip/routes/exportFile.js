const express = require('express');
const router = express.Router();
const passport = require('passport');


const exportFile =require('../controllers/export')

router.use('',passport.checkAuthentication,exportFile.downloadCSV)

module.exports=router;
